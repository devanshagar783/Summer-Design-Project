package com.sdp.remotehealthcareapp.Activities.Rebundant;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.sdp.remotehealthcareapp.R;

public class JoyInterface extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_joy_interface);
    }
}